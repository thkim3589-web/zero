
심도측정 V4.0 Android Studio 프로젝트 구성 예제

포함:
- SplashActivity 설계
- MainActivity 설계
- AndroidManifest 예제
- Gradle 적용 체크리스트
- Play Store 배포 준비 체크리스트

실제 APK 생성은 Android Studio에서 빌드 필요
